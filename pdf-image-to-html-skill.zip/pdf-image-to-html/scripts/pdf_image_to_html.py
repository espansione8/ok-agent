#!/usr/bin/env python3
"""
pdf_image_to_html.py

Convert a screenshot, mockup, PDF, .ai, or .psd design into one or more
self-contained HTML+Tailwind files using one vision-LLM call per page.
No backend service, no build step -- this is a plain, deterministic script.

Requires:
    pip install openai pymupdf psd-tools   # psd-tools only needed for .psd input

Examples:
    # Local vision model behind an OpenAI-compatible server (e.g. llama-server)
    python pdf_image_to_html.py design.png \\
        --base-url http://localhost:8080/v1 --model qwen2.5-vl --api-key none

    # OpenAI
    python pdf_image_to_html.py spec.pdf \\
        --base-url https://api.openai.com/v1 --model gpt-4o \\
        --api-key-env OPENAI_API_KEY

    # Merge every PDF page into one flowing page instead of one file each
    python pdf_image_to_html.py spec.pdf --combine \\
        --model gpt-4o --api-key-env OPENAI_API_KEY

    # Illustrator or Photoshop source -- also pulls real embedded photos/
    # logos into assets/ so the model references them instead of guessing
    python pdf_image_to_html.py mockup.psd --model gpt-4o --api-key-env OPENAI_API_KEY
"""

from __future__ import annotations

import argparse
import base64
import logging
import mimetypes
import os
import re
import time
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("pdf_image_to_html")

DEFAULT_MAX_TOKENS = 8000
DEFAULT_DPI = 144
DEFAULT_MIN_ASSET_DIM = 48  # px; skip tiny icon/chrome fragments, keep real photos/logos
RASTER_SUFFIXES = {".png", ".jpg", ".jpeg", ".webp", ".gif"}
PDF_LIKE_SUFFIXES = {".pdf", ".ai"}  # .ai files are usually PDF-compatible under the hood

SYSTEM_PROMPT = """You are a meticulous frontend developer. You will be shown one or more
images: a reference design (a screenshot, mockup, or design-file page).
Reproduce it as a single, self-contained, GENUINELY RESPONSIVE HTML page
using real Tailwind CSS utility classes -- no build step, no framework.

Responsive is the deliverable, not an afterthought:
- Build with flex/grid and Tailwind's spacing/typography scale so the page
  reflows at different widths. Do not lay the page out with one big
  fixed-pixel container and absolutely-positioned children scaled by a
  single CSS transform -- that reproduces one screenshot, not a page, and
  it is not an acceptable output no matter how visually close it looks at
  the reference size.
- Use responsive prefixes (sm:/md:/lg:) so text sizing, spacing, and
  flex-direction actually change across breakpoints, not just a uniform
  scale-to-fit.
- A multi-column source layout should typically become flex-col on mobile
  and flex-row (or similar) from md: up -- check that the design doesn't
  just visually shrink but actually restacks.

Precision rules:
- Match colors and typography as closely as the image allows. If a color
  isn't a standard Tailwind shade, use an arbitrary value like
  bg-[#1a2b3c] rather than rounding to the nearest default.
- Reproduce the visible text exactly as written, including labels, prices,
  and body copy -- don't summarize or invent copy that isn't shown. This
  applies even when that text was rendered as outlined/vector art in the
  source (common for stylized headlines/logos) with no extractable
  character data behind it -- retype what you can read visually as real
  text in a similarly-styled web font, rather than leaving it out or
  treating ordinary body copy as an image.
- Write out every repeated element in full (every nav link, every row,
  every card). Never collapse repetition into a comment like
  "<!-- repeat for remaining items -->" -- that comment is not valid
  output and will be treated as a failure.
- Don't leave TODO-style placeholders anywhere in the markup.
- For images you can't extract directly, use a placeholder from
  https://placehold.co sized to match the original, with a detailed
  alt description of what belongs there so an image model could fill
  it in later.
- If a list of real extracted assets is given below, use each one's exact
  file path in its <img src="..."> instead of a placeholder wherever that
  asset appears in the design. Treat a self-contained decorative graphic
  (a logo lockup, a badge, brand art built from many small vector shapes
  with no independent text content) as ONE image asset -- don't try to
  rebuild it out of individual positioned HTML elements.

Libraries (all via CDN, no npm install):
- Tailwind: <script src="https://cdn.tailwindcss.com"></script>
- Icons: Font Awesome or Google Fonts via their standard CDN <link> tags,
  only if the design clearly uses icons/custom type.

Output format:
- Return ONLY the HTML document, starting at <!DOCTYPE html> and ending
  at </html>.
- No markdown code fences, no explanation before or after, no "Here's
  the code:" preamble.
"""

COMBINE_INSTRUCTIONS = (
    "These images are consecutive sections of one page, in order. Reproduce "
    "them as a single HTML file with the sections stacked vertically in the "
    "order given, separated by a visible divider -- not as separate documents."
)
DEFAULT_INSTRUCTIONS = "Reproduce this design as a single HTML file."


def encode_image(path: Path) -> tuple[str, str]:
    mime = mimetypes.guess_type(str(path))[0] or "image/png"
    data = base64.b64encode(path.read_bytes()).decode()
    return mime, data


# ---------------------------------------------------------------------------
# Input normalization: turn any supported source into flat preview images
# ---------------------------------------------------------------------------

def rasterize_source(path: Path, dpi: int, out_dir: Path) -> list[Path]:
    """Produce the flattened preview image(s) that get sent to the vision
    model. Handles plain raster images, PDF/AI, and PSD."""
    suffix = path.suffix.lower()
    if suffix in RASTER_SUFFIXES:
        return [path]
    if suffix in PDF_LIKE_SUFFIXES:
        return pdf_to_images(path, dpi, out_dir)
    if suffix == ".psd":
        return [psd_to_composite(path, out_dir)]
    raise SystemExit(
        f"Unsupported input type: {suffix}. Supported: "
        f"{', '.join(sorted(RASTER_SUFFIXES | PDF_LIKE_SUFFIXES | {'.psd'}))}"
    )


def pdf_to_images(pdf_path: Path, dpi: int, out_dir: Path) -> list[Path]:
    """Rasterize each page of a PDF (or PDF-compatible .ai file) to a PNG."""
    try:
        import fitz  # PyMuPDF
    except ImportError as exc:
        raise SystemExit(
            "PyMuPDF is required for PDF/AI input. Install with: pip install pymupdf"
        ) from exc

    try:
        doc = fitz.open(pdf_path)
    except Exception as exc:
        hint = (
            " If this is an .ai file, re-save it from Illustrator with "
            "'Create PDF Compatible File' checked, or export a PDF/PNG instead."
            if pdf_path.suffix.lower() == ".ai"
            else ""
        )
        raise SystemExit(f"Could not open {pdf_path.name}: {exc}.{hint}") from exc

    out_dir.mkdir(parents=True, exist_ok=True)
    pages: list[Path] = []
    for i, page in enumerate(doc):
        pix = page.get_pixmap(dpi=dpi)
        out_path = out_dir / f"{pdf_path.stem}_p{i + 1}.png"
        pix.save(out_path)
        pages.append(out_path)
        log.info("Rasterized page %d -> %s", i + 1, out_path)
    doc.close()
    return pages


def psd_to_composite(psd_path: Path, out_dir: Path) -> Path:
    """Render a PSD's flattened composite (all visible layers merged) --
    this is the equivalent of a single PDF page for the preview call."""
    try:
        from psd_tools import PSDImage
    except ImportError as exc:
        raise SystemExit(
            "psd-tools is required for PSD input. Install with: pip install psd-tools"
        ) from exc

    out_dir.mkdir(parents=True, exist_ok=True)
    psd = PSDImage.open(psd_path)
    composite = psd.composite()
    out_path = out_dir / f"{psd_path.stem}_composite.png"
    composite.save(out_path)
    log.info("Rendered PSD composite -> %s", out_path)
    return out_path


# ---------------------------------------------------------------------------
# Real asset extraction: pull actual embedded photos/logos out of layered
# source files so the model references them instead of inventing placeholders.
# This does NOT attempt full layer recomposition -- blend modes, adjustment
# layers, and clipping masks don't decompose cleanly into standalone images,
# so this only pulls genuine raster content above a minimum size.
# ---------------------------------------------------------------------------

def extract_assets(path: Path, out_dir: Path, min_dim: int) -> list[dict]:
    suffix = path.suffix.lower()
    assets_dir = out_dir / "assets"
    if suffix in PDF_LIKE_SUFFIXES:
        return _extract_pdf_assets(path, assets_dir, min_dim)
    if suffix == ".psd":
        return _extract_psd_assets(path, assets_dir, min_dim)
    return []  # plain screenshots have no separable embedded assets


def _extract_pdf_assets(path: Path, assets_dir: Path, min_dim: int) -> list[dict]:
    """Render each embedded image's placement rect through the page's own
    compositor, instead of pulling the raw XObject stream via
    doc.extract_image(xref).

    doc.extract_image() returns the wrong thing for a meaningful slice of
    real-world PDFs: images with an Indexed colorspace, or a separate SMask
    (soft mask / alpha channel) object, can come back as just the mask --
    a flat silhouette -- with no color data at all, or as raw indexed pixel
    data with no palette applied. This is silent: it returns a valid-looking
    image dict, just the wrong pixels. It's not a corner case -- a plain
    marketing flyer with a cutout product photo and an indexed-color logo
    hit both variants in the same file during testing.

    page.get_pixmap(clip=rect, alpha=True) asks MuPDF to render that
    rectangle the same way it renders the full page: colorspace resolution,
    alpha compositing, and paint order are all handled by the one renderer
    that's actually authoritative, instead of us re-deriving them from
    lower-level stream data.
    """
    import fitz

    doc = fitz.open(path)
    manifest: list[dict] = []
    seen_xrefs: set[int] = set()
    for page in doc:
        for info in page.get_image_info(xrefs=True):
            xref = info.get("xref")
            if not xref or xref in seen_xrefs:
                continue
            seen_xrefs.add(xref)
            rect = fitz.Rect(info["bbox"]) & page.rect  # clip to visible page area
            if rect.is_empty or rect.width < min_dim or rect.height < min_dim:
                continue
            assets_dir.mkdir(parents=True, exist_ok=True)
            pix = page.get_pixmap(clip=rect, alpha=True, dpi=150)
            fname = f"asset_{xref}.png"
            pix.save(assets_dir / fname)
            manifest.append({"file": f"assets/{fname}", "width": pix.width, "height": pix.height})
    doc.close()
    log.info("Extracted %d embedded image asset(s) to %s", len(manifest), assets_dir)
    return manifest


def extract_vector_region(path: Path, assets_dir: Path, rect: "fitz.Rect", name: str, dpi: int = 300) -> dict:
    """Crop a region of vector-built artwork (a logo lockup made of many
    overlapping curve fills, for instance) straight from the page render.

    Don't try to replay page.get_drawings() items as individually styled
    HTML/SVG elements to reconstruct something like this -- a compound
    path with fill holes (e.g. letterforms with counters) degrades badly if
    approximated by each sub-shape's bounding-box rectangle, and paint
    order between vector fills and any interleaved images has to match
    the original exactly or elements end up stacked wrong. A dozen
    overlapping bounding-box rectangles in the same six colors is
    indistinguishable from noise. Call this manually for any region you
    can see is decorative brand art rather than reflowable content --
    it's the same clip-render technique as _extract_pdf_assets, just
    aimed at a region you pick instead of one tied to an embedded image.
    """
    import fitz

    doc = fitz.open(path)
    page = doc[0]
    assets_dir.mkdir(parents=True, exist_ok=True)
    pix = page.get_pixmap(clip=rect, dpi=dpi)
    fname = f"{name}.png"
    pix.save(assets_dir / fname)
    doc.close()
    log.info("Cropped vector region '%s' -> %s", name, assets_dir / fname)
    return {"file": f"assets/{fname}", "width": pix.width, "height": pix.height}


def _extract_psd_assets(path: Path, assets_dir: Path, min_dim: int) -> list[dict]:
    from psd_tools import PSDImage

    psd = PSDImage.open(path)
    manifest: list[dict] = []
    for layer in psd.descendants():
        if not layer.is_visible():
            continue
        if layer.kind != "pixel":  # skip groups, adjustment, shape, and text layers
            continue
        if layer.width < min_dim or layer.height < min_dim:
            continue
        img = layer.composite()
        if img is None:
            continue
        assets_dir.mkdir(parents=True, exist_ok=True)
        safe_name = re.sub(r"[^\w.-]", "_", layer.name) or f"layer_{layer.layer_id}"
        fname = f"{safe_name}.png"
        img.save(assets_dir / fname)
        manifest.append({"file": f"assets/{fname}", "width": layer.width, "height": layer.height, "layer": layer.name})
    log.info("Extracted %d raster layer(s) to %s", len(manifest), assets_dir)
    return manifest


def build_asset_note(manifest: list[dict]) -> str:
    if not manifest:
        return ""
    lines = "\n".join(f"- {a['file']} (~{a['width']}x{a['height']}px)" for a in manifest)
    return (
        "\n\nReal image assets were extracted from the source file and saved "
        "next to the output. Where the design shows one of these, reference "
        "its exact file path in the <img> tag instead of a placeholder:\n" + lines
    )


# ---------------------------------------------------------------------------
# Model call and output handling
# ---------------------------------------------------------------------------

def extract_html(raw: str) -> str:
    """Pull a clean HTML document out of a model response, tolerating
    stray prose or code fences the model adds despite instructions."""
    cleaned = re.sub(r"^```(?:html)?\s*|\s*```$", "", raw.strip(), flags=re.M)
    match = re.search(r"<!DOCTYPE html.*?</html>", cleaned, re.S | re.I)
    if match:
        return match.group(0).strip()
    match = re.search(r"<html.*?</html>", cleaned, re.S | re.I)
    if match:
        return match.group(0).strip()
    log.warning(
        "Could not find a <html>...</html> block in the response. "
        "Returning the raw text as-is -- check the .raw.txt file next to "
        "the output to see exactly what the model sent back."
    )
    return cleaned.strip()


def call_vision_model(
    image_paths: list[Path],
    *,
    base_url: str,
    api_key: str,
    model: str,
    instructions: str,
    max_tokens: int,
) -> str:
    from openai import OpenAI

    client = OpenAI(base_url=base_url, api_key=api_key)
    content: list[dict] = [{"type": "text", "text": instructions}]
    for path in image_paths:
        mime, data = encode_image(path)
        content.append(
            {"type": "image_url", "image_url": {"url": f"data:{mime};base64,{data}"}}
        )

    log.info("Calling %s with %d image(s)...", model, len(image_paths))
    start = time.time()
    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": content},
        ],
        max_tokens=max_tokens,
    )
    log.info("Response received in %.1fs", time.time() - start)
    return response.choices[0].message.content


def write_result(raw: str, out_dir: Path, label: str) -> Path:
    """Always write the raw response alongside the extracted HTML.
    This is the single biggest debugging win: when extraction fails or
    the output looks wrong, you look at label.raw.txt, not the model's
    provider dashboard."""
    (out_dir / f"{label}.raw.txt").write_text(raw)
    html = extract_html(raw)
    out_path = out_dir / f"{label}.html"
    out_path.write_text(html)
    log.info("Wrote %s (raw response: %s.raw.txt)", out_path, label)
    return out_path


def main() -> None:
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument("input", type=Path, help="Image, PDF, .ai, or .psd file to convert")
    parser.add_argument("--model", required=True, help="Vision-capable model name")
    parser.add_argument(
        "--base-url", default="https://api.openai.com/v1", help="OpenAI-compatible API base URL"
    )
    parser.add_argument("--api-key", default=None, help="API key value (overrides --api-key-env)")
    parser.add_argument(
        "--api-key-env", default="OPENAI_API_KEY", help="Env var to read the API key from"
    )
    parser.add_argument("--dpi", type=int, default=DEFAULT_DPI, help="PDF/AI rasterization DPI")
    parser.add_argument("--max-tokens", type=int, default=DEFAULT_MAX_TOKENS)
    parser.add_argument(
        "--combine", action="store_true",
        help="Merge all pages into one HTML file instead of one file per page",
    )
    parser.add_argument("--out-dir", type=Path, default=None, help="Output directory")
    parser.add_argument(
        "--instructions", default=None, help="Override the default per-call instruction text"
    )
    parser.add_argument(
        "--skip-assets", action="store_true",
        help="Don't extract embedded raster assets from .ai/.psd/.pdf sources",
    )
    parser.add_argument(
        "--min-asset-size", type=int, default=DEFAULT_MIN_ASSET_DIM,
        help="Minimum width/height in px for an extracted asset to be kept",
    )
    args = parser.parse_args()

    if not args.input.exists():
        parser.error(f"Input file not found: {args.input}")

    api_key = args.api_key or os.environ.get(args.api_key_env)
    if not api_key:
        parser.error(f"No API key: pass --api-key or set ${args.api_key_env}")

    out_dir = args.out_dir or args.input.parent / f"{args.input.stem}_html"
    out_dir.mkdir(parents=True, exist_ok=True)

    images = rasterize_source(args.input, args.dpi, out_dir / "pages")

    asset_note = ""
    if not args.skip_assets:
        manifest = extract_assets(args.input, out_dir, args.min_asset_size)
        asset_note = build_asset_note(manifest)

    if args.combine and len(images) > 1:
        raw = call_vision_model(
            images,
            base_url=args.base_url,
            api_key=api_key,
            model=args.model,
            instructions=(args.instructions or COMBINE_INSTRUCTIONS) + asset_note,
            max_tokens=args.max_tokens,
        )
        write_result(raw, out_dir, "combined")
    else:
        for i, img in enumerate(images):
            label = args.input.stem if len(images) == 1 else f"{args.input.stem}_p{i + 1}"
            raw = call_vision_model(
                [img],
                base_url=args.base_url,
                api_key=api_key,
                model=args.model,
                instructions=(args.instructions or DEFAULT_INSTRUCTIONS) + asset_note,
                max_tokens=args.max_tokens,
            )
            write_result(raw, out_dir, label)


if __name__ == "__main__":
    main()
